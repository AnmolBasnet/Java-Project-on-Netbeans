
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
//This class is built to do binary search in the program.
public class BinarySearch {
    public static int binarySearchByPrice(LinkedList <Integer> prices, int searchPrice){    
        int first = 0;
        int last = prices.size() - 1;
        
        while(first <= last){
            int middle = (first+last)/2;
            int midValue = prices.get(middle);
            
            if (midValue < searchPrice){
               first = middle + 1; 
            }
            else if (middle>0 &&  prices.get(middle-1)>=searchPrice){
                last = middle - 1;
            }
            else if(midValue == searchPrice){
                return middle;
            }
            else{
                return ~middle;
            }
        }
        return -1;
    }
    public static int binarySearchByBrand(LinkedList<String> brands, String searchBrand){ 
        int first = 0;
        int last = brands.size() - 1; 
        
        while (first <= last){  
            int middle = first + (last - first)/2;
            
            int res = searchBrand.compareTo(brands.get(middle).toLowerCase()); 

            if (res == 0){ 
                return middle;
            }
            if (res > 0){ 
                first = middle + 1; 
            }
            else{
                last = middle - 1; 
            }
        } 
        return -1;
    }
}
