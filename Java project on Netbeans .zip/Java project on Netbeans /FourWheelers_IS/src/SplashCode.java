
import java.util.concurrent.TimeUnit;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
//This class is built to run Splash Screen. 
public class SplashCode {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SplashScreen screen = new SplashScreen();
        screen.setVisible(true);
        try{
            for(int i=0;i<=100;i++){
                Thread.sleep(30);
                screen.percentLbl.setText(""+i+"%");
                screen.jProgressBarSplash.setValue(i);
                if(i == 100){
                    screen.percentLbl.setText("");
                    screen.wheelersLbl.setText("4Wheelers...");
                    TimeUnit.SECONDS.sleep(1);
                    FourWheelers_Info home = new FourWheelers_Info();
                    home.setVisible(true);
                    screen.setVisible(false);
                }
            }
        }
        catch(Exception e){}
    }
    
}
