
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
//This class is built to sort the data for searching
public class Sort {
    public static void swap(LinkedList <Integer> a, int minPos, int i){
        int temp = a.get(minPos);
        a.set(minPos, a.get(i));
        a.set(i, temp);
    }
    
    public static void swapString(LinkedList <String> a, int minPos, int i){
        String temp = a.get(minPos);
        a.set(minPos, a.get(i));
        a.set(i, temp);
    }
    public static void sort(LinkedList <Integer> a, LinkedList <String> b){  
        for (int i = 0; i < a.size() - 1; i++){  
            //3
            int minPos = minimumPosition(a, i);
            swap(a, minPos, i);
            swapString(b, minPos, i);
        } 
    }
    private static int minimumPosition(LinkedList <Integer> a, int from){  
        int minPos = from;
        for (int i = from + 1; i < a.size(); i++){
            if (a.get(i) < a.get(minPos)) { 
                 minPos = i; 
            }
        }
        return minPos;//3   
   }
    public static void sortSelect(LinkedList <String> b, LinkedList <String> a){
        for ( int j=0; j < b.size()-1; j++ ){

            int min = j;
            for (int k=j+1; k < b.size(); k++)
                if ( b.get(k).compareTo( b.get(min) ) < 0 ) min = k;  

            String temp = b.get(j);
            b.set(j, b.get(min));
            b.set(min, temp);

            String tempa = a.get(j);
            a.set(j, a.get(min));
            a.set(min, tempa);  
        }
    }
}
